#!/bin/bash
# Builds ClaudeMini for iOS 12 (arm64) and packages it as a .deb.
# Runs on a macOS machine with Xcode (GitHub Actions: macos-latest).
set -euo pipefail
cd "$(dirname "$0")"

APP="ClaudeMini"
BUNDLE_ID="com.puc.claudemini"
VERSION="$(tr -d '[:space:]' < VERSION)"
OUT="build"
APPDIR="$OUT/pkg/Applications/$APP.app"
DIST="dist"

rm -rf "$OUT" "$DIST"
mkdir -p "$APPDIR" "$DIST"

SDK="$(xcrun --sdk iphoneos --show-sdk-path)"
echo "SDK: $SDK"

echo "==> Compiling (arm64, iOS 12.0+)"
xcrun --sdk iphoneos clang \
  -arch arm64 \
  -miphoneos-version-min=12.0 \
  -isysroot "$SDK" \
  -fobjc-arc -fmodules -O2 -Wall -Wno-deprecated-declarations \
  src/*.m src/*.c \
  -framework UIKit -framework Foundation -framework Security -framework WebKit -framework ImageIO -lz \
  -o "$APPDIR/$APP"

echo "==> Assembling bundle"
cp app/Info.plist "$APPDIR/Info.plist"
/usr/libexec/PlistBuddy -c "Set :CFBundleShortVersionString $VERSION" "$APPDIR/Info.plist"
/usr/libexec/PlistBuddy -c "Set :CFBundleIdentifier $BUNDLE_ID" "$APPDIR/Info.plist"
cp -R app/Resources/. "$APPDIR/"
printf 'APPL????' > "$APPDIR/PkgInfo"
find "$OUT" -name '.DS_Store' -delete

echo "==> Pseudo-signing with ldid"
ldid -Sapp/entitlements.plist "$APPDIR/$APP"

echo "==> Packaging .deb"
mkdir -p "$OUT/pkg/DEBIAN"
cp deb/DEBIAN/postinst deb/DEBIAN/postrm "$OUT/pkg/DEBIAN/"
sed "s/@VERSION@/$VERSION/" deb/DEBIAN/control > "$OUT/pkg/DEBIAN/control"
chmod 755 "$OUT/pkg/DEBIAN/postinst" "$OUT/pkg/DEBIAN/postrm"
find "$OUT/pkg/Applications" -type d -exec chmod 755 {} +
find "$OUT/pkg/Applications" -type f -exec chmod 644 {} +
chmod 755 "$APPDIR/$APP"

export COPYFILE_DISABLE=1
DEB="$DIST/${BUNDLE_ID}_${VERSION}_iphoneos-arm.deb"
dpkg-deb --root-owner-group -Zgzip -b "$OUT/pkg" "$DEB"

echo "==> Done: $DEB"
dpkg-deb -I "$DEB" | head -n 15
