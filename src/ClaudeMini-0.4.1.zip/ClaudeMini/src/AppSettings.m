#import "AppSettings.h"

const NSUInteger kMaxSystemPromptChars = 4000;
static NSString *const kSystemPromptKey = @"systemPrompt";

@implementation AppSettings

+ (NSString *)systemPrompt {
    NSString *value = [[NSUserDefaults standardUserDefaults] stringForKey:kSystemPromptKey];
    return value ?: @"";
}

+ (void)setSystemPrompt:(NSString *)prompt {
    NSString *trimmed = [prompt stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (trimmed.length > kMaxSystemPromptChars) {
        NSRange safe = [trimmed rangeOfComposedCharacterSequencesForRange:NSMakeRange(0, kMaxSystemPromptChars)];
        trimmed = [trimmed substringWithRange:safe];
    }
    if (trimmed.length == 0) {
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:kSystemPromptKey];
    } else {
        [[NSUserDefaults standardUserDefaults] setObject:trimmed forKey:kSystemPromptKey];
    }
    [[NSUserDefaults standardUserDefaults] synchronize];
}

@end
