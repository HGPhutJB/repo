#import "SettingsViewController.h"
#import "Strings.h"
#import "Theme.h"
#import "KeyStore.h"
#import "AppSettings.h"
#import "ConversationStore.h"
#import "RootViewController.h"
#import "SystemPromptViewController.h"

typedef NS_ENUM(NSInteger, SettingsSection) {
    SettingsSectionKeys = 0,
    SettingsSectionAssistant,
    SettingsSectionGeneral,
    SettingsSectionHistory,
    SettingsSectionAbout,
    SettingsSectionCount
};

@interface SettingsViewController ()
@property (strong, nonatomic) UITableView *tableView;
@end

@implementation SettingsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = L(@"settings_title");
    self.view.backgroundColor = [Theme background];
    self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"" style:UIBarButtonItemStylePlain target:nil action:nil];

    self.tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStyleGrouped];
    self.tableView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.backgroundColor = [Theme background];
    self.tableView.separatorColor = [Theme border];
    [self.view addSubview:self.tableView];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.tableView reloadData];   // keys / system prompt may have changed on the next screen
}

#pragma mark - Helpers

- (NSString *)maskedKeyFor:(AIProvider)provider {
    NSString *key = [KeyStore loadKeyForProvider:provider];
    if (key.length == 0) return L(@"api_key_none");
    NSString *tail = key.length > 4 ? [key substringFromIndex:key.length - 4] : key;
    return [@"\u2022\u2022\u2022\u2022" stringByAppendingString:tail];
}

- (NSString *)languageName {
    NSString *preference = [Loc preference];
    if ([preference isEqualToString:@"vi"]) return @"Ti\u1EBFng Vi\u1EC7t";
    if ([preference isEqualToString:@"en"]) return @"English";
    return L(@"language_auto");
}

#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return SettingsSectionCount;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return section == SettingsSectionKeys ? 2 : 1;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    return section == SettingsSectionKeys ? L(@"keys_header") : nil;
}

- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section {
    if (section == SettingsSectionKeys) return L(@"keys_footer");
    if (section == SettingsSectionAbout) return L(@"privacy_footer");
    return nil;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:nil];
    cell.backgroundColor = [Theme surface];
    cell.textLabel.font = [UIFont systemFontOfSize:17];
    cell.textLabel.textColor = [Theme text];
    cell.detailTextLabel.font = [UIFont systemFontOfSize:16];
    cell.detailTextLabel.textColor = [Theme secondaryText];

    switch (indexPath.section) {
        case SettingsSectionKeys: {
            AIProvider provider = indexPath.row == 0 ? AIProviderGemini : AIProviderClaude;
            cell.textLabel.text = provider == AIProviderClaude ? L(@"api_key_claude") : L(@"api_key_gemini");
            cell.detailTextLabel.text = [self maskedKeyFor:provider];
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
            break;
        }
        case SettingsSectionAssistant:
            cell.textLabel.text = L(@"system_prompt_title");
            cell.detailTextLabel.text = [AppSettings systemPrompt].length > 0 ? L(@"system_prompt_set") : L(@"system_prompt_unset");
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
            break;
        case SettingsSectionGeneral:
            cell.textLabel.text = L(@"language");
            cell.detailTextLabel.text = [self languageName];
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
            break;
        case SettingsSectionHistory:
            cell.textLabel.text = L(@"clear_history");
            cell.textLabel.textColor = [Theme error];
            break;
        default:
            cell.textLabel.text = L(@"version");
            cell.detailTextLabel.text = [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleShortVersionString"];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            break;
    }
    return cell;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    switch (indexPath.section) {
        case SettingsSectionKeys: {
            RootViewController *keyScreen = [[RootViewController alloc] init];
            keyScreen.embedded = YES;
            keyScreen.provider = indexPath.row == 0 ? AIProviderGemini : AIProviderClaude;
            [self.navigationController pushViewController:keyScreen animated:YES];
            break;
        }
        case SettingsSectionAssistant:
            [self.navigationController pushViewController:[[SystemPromptViewController alloc] init] animated:YES];
            break;
        case SettingsSectionGeneral:
            [self chooseLanguage];
            break;
        case SettingsSectionHistory:
            [self confirmClearHistory];
            break;
        default:
            break;
    }
}

#pragma mark - Language

- (void)chooseLanguage {
    UIAlertController *sheet = [UIAlertController alertControllerWithTitle:L(@"language")
                                                                   message:nil
                                                            preferredStyle:UIAlertControllerStyleActionSheet];
    NSArray *options = @[ @[@"auto", L(@"language_auto")], @[@"vi", @"Ti\u1EBFng Vi\u1EC7t"], @[@"en", @"English"] ];
    for (NSArray *option in options) {
        NSString *value = option[0];
        UIAlertAction *action = [UIAlertAction actionWithTitle:option[1] style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) {
            if ([[Loc preference] isEqualToString:value]) return;
            [Loc setPreference:value];
            // The app rebuilds its screens in the new language (the open chat starts fresh).
            [[NSNotificationCenter defaultCenter] postNotificationName:kNotifLanguageChanged object:nil];
        }];
        [sheet addAction:action];
    }
    [sheet addAction:[UIAlertAction actionWithTitle:L(@"cancel") style:UIAlertActionStyleCancel handler:nil]];
    NSIndexPath *path = [NSIndexPath indexPathForRow:0 inSection:SettingsSectionGeneral];
    sheet.popoverPresentationController.sourceView = [self.tableView cellForRowAtIndexPath:path] ?: self.view;
    sheet.popoverPresentationController.sourceRect = sheet.popoverPresentationController.sourceView.bounds;
    [self presentViewController:sheet animated:YES completion:nil];
}

#pragma mark - History

- (void)confirmClearHistory {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:L(@"clear_history_confirm_title")
                                                                   message:L(@"clear_history_confirm_msg")
                                                            preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:L(@"cancel") style:UIAlertActionStyleCancel handler:nil]];
    __weak typeof(self) weakSelf = self;
    [alert addAction:[UIAlertAction actionWithTitle:L(@"delete") style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
        [ConversationStore deleteAll];
        [[NSNotificationCenter defaultCenter] postNotificationName:kNotifHistoryCleared object:nil];
        SettingsViewController *me = weakSelf;
        if (!me) return;
        UIAlertController *done = [UIAlertController alertControllerWithTitle:nil
                                                                      message:L(@"history_cleared")
                                                               preferredStyle:UIAlertControllerStyleAlert];
        [done addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
        [me presentViewController:done animated:YES completion:nil];
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

@end
