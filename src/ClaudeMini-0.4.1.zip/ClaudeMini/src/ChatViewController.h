#import <UIKit/UIKit.h>

// Main screen: model picker in the title, chat page (WKWebView) above, native input bar below.
@interface ChatViewController : UIViewController
@end
