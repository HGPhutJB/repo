#import <Foundation/Foundation.h>

extern const NSUInteger kMaxSystemPromptChars;

// Small app-wide preferences.
@interface AppSettings : NSObject
+ (NSString *)systemPrompt;                       // @"" when none is set
+ (void)setSystemPrompt:(NSString *)prompt;       // trimmed and cut to kMaxSystemPromptChars
@end
