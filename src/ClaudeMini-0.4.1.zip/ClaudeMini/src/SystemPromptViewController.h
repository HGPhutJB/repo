#import <UIKit/UIKit.h>

// Edits the instructions sent to the model with every message (the "system prompt"). Saved automatically.
@interface SystemPromptViewController : UIViewController <UITextViewDelegate>
@end
