#import <UIKit/UIKit.h>

// Lets the user pick a Gemini model from the live list available to their key.
@interface ModelPickerViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>
- (instancetype)initWithSelectedModel:(NSString *)modelId;
@property (copy, nonatomic) void (^onSelect)(NSString *modelId);
@end
